import React from "react";

const PageNotFound = () => {
  return (
    <div>
      <h3 className="text-center text-info">404, Page not found!!!</h3>
    </div>
  );
};

export default PageNotFound;
