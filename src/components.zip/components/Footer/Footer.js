import React from 'react';

const Footer = () => {
    return (
        <div className="mt-5">
            <p className="text-center text-muted">&copy; 2021 Learner</p>
        </div>
    );
};

export default Footer;